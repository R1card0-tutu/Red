
class SocksError(Exception):
    """Error raise for the SocksNegotiator
    """
