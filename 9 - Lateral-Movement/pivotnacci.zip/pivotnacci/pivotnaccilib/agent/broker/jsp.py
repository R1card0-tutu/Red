from .base import AgentBaseBroker


class AgentJsp(AgentBaseBroker):
    """
    Class to interact directly with the jsp agent
    """
